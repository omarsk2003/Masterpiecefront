"use strict";

(() => {
  const ui = window.LiftOnboarding;
  const form = document.getElementById("account-form");
  const password = document.getElementById("register-password");
  const confirmation = document.getElementById("confirm-password");

  function validate() {
    const name = document.getElementById("full-name");
    const email = document.getElementById("register-email");
    name.value = name.value.trim();
    email.value = email.value.trim();
    const checks = [
      ui.fieldError("full-name", name.value.length < 2 ? "Enter your full name." : ""),
      ui.fieldError("register-email", !email.value ? "Enter your email address." : email.validity.typeMismatch ? "Enter a valid email address." : ""),
      ui.fieldError("register-password", password.value.length < 8 ? "Use at least 8 characters." : ""),
      ui.fieldError("confirm-password", !confirmation.value ? "Confirm your password." : confirmation.value !== password.value ? "Passwords do not match." : ""),
      ui.fieldError("terms", !document.getElementById("terms").checked ? "Review and accept the preview terms to continue." : "")
    ];
    if (checks.includes(false)) { ui.focusInvalid(form); return false; }
    return true;
  }

  ui.validators[0] = validate;
  form.addEventListener("submit", event => {
    event.preventDefault();
    if (validate()) ui.goTo(1);
  });
  document.querySelectorAll("[data-password]").forEach(button => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.password);
      const visible = input.type === "password";
      input.type = visible ? "text" : "password";
      const label = input === confirmation ? "confirmation password" : "password";
      button.setAttribute("aria-label", (visible ? "Hide " : "Show ") + label);
      button.setAttribute("aria-pressed", String(visible));
    });
  });
  document.getElementById("open-terms").addEventListener("click", () => document.getElementById("terms-dialog").showModal());
})();


