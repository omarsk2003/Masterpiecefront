"use strict";

(() => {
  const ui = window.LiftOnboarding;
  const form = document.getElementById("plans-form");
  const planNames = { free: "Free", ai: "AI Plan", premium: "Premium" };
  form.addEventListener("submit", event => {
    event.preventDefault();
    for (let index = 0; index < 3; index++) {
      if (!ui.validators[index]()) {
        ui.goTo(index, false);
        ui.focusInvalid(document.querySelector('[data-step="' + index + '"] form'));
        return;
      }
    }
    const plan = form.querySelector('[name="plan"]:checked');
    if (!plan) return;
    const name = document.getElementById("full-name").value.trim();
    const summary = document.getElementById("complete-summary");
    const result = document.getElementById("match-result");
    result.replaceChildren();
    result.hidden = plan.value !== "premium";
    summary.textContent = name + ", you selected " + planNames[plan.value] + ".";
    if (plan.value === "premium") {
      const profile = {
        plan: plan.value,
        goal: document.querySelector('[name="goal"]:checked').value,
        sport: document.querySelector('[name="goal"]:checked').value === "performance" ? document.querySelector('[name="sport"]:checked').value : null,
        experience: document.querySelector('[name="experience"]:checked').value,
        location: document.querySelector('[name="location"]:checked').value,
        duration: Number(document.querySelector('[name="duration"]:checked').value),
        cooking: document.querySelector('[name="cooking"]:checked').value,
        conditions: [...document.querySelectorAll('[name="conditions"]:checked')].map(input => input.value)
      };
      const match = window.LiftMatching.matchPremium(profile);
      const heading = document.createElement("h3");
      heading.textContent = match.status === "matched" ? "Your matched Premium team" : "Matching needs a closer look";
      result.append(heading);
      for (const [role, person] of [["Coach", match.coach], ["Nutritionist", match.nutritionist]]) {
        const card = document.createElement("article");
        const label = document.createElement("span");
        label.textContent = role.toUpperCase();
        const title = document.createElement("strong");
        title.textContent = person?.name || "Awaiting a suitable specialist";
        const specialty = document.createElement("small");
        specialty.textContent = person?.specialty || "Admin will review available specialists.";
        const reason = document.createElement("p");
        reason.textContent = person?.reason || "We will not assign an unsuitable specialist just to fill the role.";
        card.append(label, title, specialty, reason);
        result.append(card);
      }
      const note = document.createElement("p");
      note.className = "match-note";
      note.textContent = match.note + (match.healthReview ? " Your health considerations will be reviewed by your assigned professionals before plans are approved." : "");
      result.append(note);
      const previewNote = document.createElement("p");
      previewNote.className = "match-preview-note";
      previewNote.textContent = "This matching preview is not saved. The dashboard link opens the existing sample member.";
      result.append(previewNote);
    }
    document.getElementById("complete-dialog").showModal();
  });
})();


