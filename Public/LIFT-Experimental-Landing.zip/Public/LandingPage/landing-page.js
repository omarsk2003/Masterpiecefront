"use strict";

// All content is static. No JSON, API, database or browser storage is used.
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const intro = document.getElementById("intro");
const canvas = document.getElementById("intro-canvas");
const context = canvas.getContext("2d");
const replayIntro = document.getElementById("replay-intro");
const caption = document.getElementById("intro-caption");
const brandImage = intro.querySelector("img");
let frameId = 0;
let introTimer = 0;
let closeTimer = 0;
let introActive = false;
let startedAt = 0;
let particles = [];
let width = 0;
let height = 0;
let returnFocus = null;
const pageElements = [document.querySelector("lift-navbar"), document.querySelector("main"), document.querySelector("lift-footer"), document.querySelector(".skip-link")];

function sizeCanvas() {
  width = window.innerWidth;
  height = window.innerHeight;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  context?.setTransform(ratio, 0, 0, ratio, 0, 0);
}

function prepareParticles() {
  if (!context) return;
  const sample = document.createElement("canvas");
  sample.width = 430;
  sample.height = Math.round(430 * brandImage.naturalHeight / brandImage.naturalWidth);
  const sampleContext = sample.getContext("2d", { willReadFrequently: true });
  if (!sampleContext) return;
  sampleContext.drawImage(brandImage, 0, 0, sample.width, sample.height);
  try {
    const data = sampleContext.getImageData(0, 0, sample.width, sample.height).data;
    const points = [];
    for (let y = 0; y < sample.height; y += 3) {
      for (let x = 0; x < sample.width; x += 3) {
        const index = (y * sample.width + x) * 4;
        if (data[index + 3] > 100 && (data[index] + data[index + 1] + data[index + 2]) / 3 < 205) {
          points.push({
            x: x / sample.width - .5,
            y: (y / sample.height - .5) * sample.height / sample.width,
            color: data[index + 1] > data[index] * 1.4 && data[index + 1] > 95 ? "#00F59B" : "#A3B3BC",
            phase: Math.random() * Math.PI * 2,
            radius: .55 + Math.random() * 1.05,
            offset: Math.random()
          });
        }
      }
    }
    const max = width < 700 ? 1050 : 1850;
    const stride = Math.max(1, Math.ceil(points.length / max));
    particles = points.filter((_, index) => index % stride === 0);
  } catch {
    // Direct file:// openings can restrict canvas pixel access.
    // The orbit animation still runs and the original logo is revealed.
    particles = [];
  }
}

function renderIntro(now) {
  if (!introActive || !context) return;
  const time = (now - startedAt) / 1000;
  context.clearRect(0, 0, width, height);
  const cx = width / 2;
  const cy = height * .45;
  const logoWidth = Math.min(width * (width < 700 ? .75 : .52), 570);
  const formation = Math.min(1, Math.max(0, (time - 1.15) / 2.7));
  const ease = 1 - Math.pow(1 - formation, 4);
  const fade = Math.max(0, 1 - Math.max(0, time - 4.3) / .65);

  // A slow, luminous orbit establishes the shape before the points settle.
  const glow = context.createRadialGradient(cx, cy, 0, cx, cy, Math.min(width, height) * .5);
  glow.addColorStop(0, "rgba(0,245,155," + (.15 * (1 - ease)) + ")");
  glow.addColorStop(1, "rgba(5,8,9,0)");
  context.fillStyle = glow;
  context.fillRect(0, 0, width, height);
  context.save();
  context.translate(cx, cy);
  context.rotate(-.38 + time * .13);
  for (let ring = 0; ring < 4; ring++) {
    context.beginPath();
    context.ellipse(0, 0, Math.min(width * .36, 370) + ring * 12, 100 + ring * 13, ring * .2, 0, Math.PI * 2);
    context.strokeStyle = "rgba(0,245,155," + (.18 * (1 - ease) * (1 - ring * .18)) + ")";
    context.lineWidth = .7;
    context.stroke();
  }
  context.restore();
  const items = particles.length ? particles : Array.from({ length: 160 }, (_, index) => ({
    phase: index * .15, offset: (index % 20) / 20, radius: 1, x: 0, y: 0, color: "#00F59B"
  }));
  for (const particle of items) {
    const angle = particle.phase + time * (1.2 + particle.offset);
    const radius = (Math.min(width, height) * .27 + particle.offset * 120) * (1 + .09 * Math.sin(time));
    const orbitX = cx + Math.cos(angle) * radius;
    const orbitY = cy + Math.sin(angle) * radius * .45;
    const localEase = particles.length ? Math.min(1, ease * (1 + particle.offset * .03)) : 0;
    const x = orbitX + (cx + particle.x * logoWidth - orbitX) * localEase;
    const y = orbitY + (cy + particle.y * logoWidth - orbitY) * localEase;
    context.globalAlpha = fade * (.4 + particle.offset * .6);
    context.fillStyle = particle.color;
    context.beginPath();
    context.arc(x, y, particle.radius * (.8 + (1 - ease) * .35), 0, Math.PI * 2);
    context.fill();
    if (formation < .6) {
      context.globalAlpha = .12 * fade * (1 - formation);
      context.beginPath();
      context.moveTo(x, y);
      context.lineTo(x - Math.cos(angle + Math.PI / 2) * 12, y - Math.sin(angle + Math.PI / 2) * 7);
      context.strokeStyle = particle.color;
      context.stroke();
    }
  }
  context.globalAlpha = 1;
  caption.textContent = time < 1.5 ? "FIND YOUR ENERGY" : time < 3.3 ? "FIND YOUR BALANCE" : "THIS IS LIFT";
  if (time >= 4.05) intro.classList.add("logo-visible");
  if (time >= 5.8) {
    finishIntro();
    return;
  }
  frameId = requestAnimationFrame(renderIntro);
}

function finishIntro(immediate = false) {
  if (!introActive) return;
  introActive = false;
  cancelAnimationFrame(frameId);
  clearTimeout(introTimer);
  intro.classList.add("exiting");
  const complete = () => {
    intro.hidden = true;
    document.body.classList.remove("intro-running");
    pageElements.forEach(element => { if (element) element.inert = false; });
    window.dispatchEvent(new Event("lift:intro-finished"));
    if (returnFocus && document.contains(returnFocus)) returnFocus.focus({ preventScroll: true });
  };
  if (immediate || reduceMotion.matches) complete();
  else closeTimer = window.setTimeout(complete, 850);
}

function startIntro(replay = false) {
  if (introActive) return;
  clearTimeout(closeTimer);
  returnFocus = replay ? replayIntro : null;
  introActive = true;
  window.dispatchEvent(new Event("lift:intro-started"));
  intro.hidden = false;
  intro.classList.remove("exiting", "logo-visible", "playing");
  document.body.classList.add("intro-running");
  pageElements.forEach(element => { if (element) element.inert = true; });
  intro.focus({ preventScroll: true });
  sizeCanvas();
  prepareParticles();
  // A safety timeout always releases the page if an animation frame fails.
  introTimer = window.setTimeout(() => finishIntro(true), 7500);
  startedAt = performance.now();
  requestAnimationFrame(() => intro.classList.add("playing"));
  if (reduceMotion.matches || !context) {
    intro.classList.add("logo-visible");
    clearTimeout(introTimer);
    introTimer = window.setTimeout(finishIntro, 2200);
  } else frameId = requestAnimationFrame(renderIntro);
}

intro.addEventListener("keydown", event => {
  if (event.key === "Tab") { event.preventDefault(); intro.focus(); }
});
replayIntro.addEventListener("click", () => startIntro(true));
window.addEventListener("resize", () => { if (introActive) sizeCanvas(); });
reduceMotion.addEventListener("change", () => {
  replayIntro.hidden = reduceMotion.matches;
});
replayIntro.hidden = reduceMotion.matches;
if (brandImage.complete && brandImage.naturalWidth) startIntro();
else {
  brandImage.addEventListener("load", () => startIntro(), { once: true });
  brandImage.addEventListener("error", () => { intro.hidden = true; window.dispatchEvent(new Event("lift:intro-finished")); }, { once: true });
}

// Sections remain readable without JavaScript or IntersectionObserver.
if ("IntersectionObserver" in window && !reduceMotion.matches) {
  document.documentElement.classList.add("js-reveal");
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    }
  }, { threshold: .08 });
  document.querySelectorAll(".reveal").forEach(element => observer.observe(element));
}

const steps = [
  {
    tag: "A PLAN STARTS WITH A PERSON",
    title: "Your life is the starting point.",
    description: "Tell LIFT about your goals, daily routine, available time and food preferences. The AI conversation fills in the details — so your plan starts with understanding.",
    labels: ["My goal", "My time", "My meals"],
    values: ["Feel stronger ↗", "45 minutes a day", "Made at home"],
    note: "A little context. A much better plan."
  },
  {
    tag: "INTELLIGENCE WITH INTENTION",
    title: "A plan that moves with you.",
    description: "Your AI creates workouts and nutrition guidance around your actual routine. Train at home or at the gym. Work with meals you already enjoy. Make progress at a pace you can sustain.",
    labels: ["Your movement", "Your nutrition", "Your rhythm"],
    values: ["A tailored workout", "Practical portions", "Built around your week"],
    note: "Less guesswork. More time for you."
  },
  {
    tag: "THE PREMIUM EXPERIENCE",
    title: "Real people. On your side.",
    description: "LIFT matches you with a coach and nutritionist suited to your goals. They review your AI drafts, talk through your needs, make adjustments and approve each plan before you start.",
    labels: ["Your coach", "Your nutritionist", "Your plan"],
    values: ["Matched to your goals", "Chosen by you", "Reviewed, then approved"],
    note: "Your experts. Your conversations. Your progress."
  }
];
const tabs = [...document.querySelectorAll(".step-tab")];
function chooseStep(index) {
  const step = steps[index];
  tabs.forEach((tab, number) => {
    tab.classList.toggle("active", number === index);
    tab.setAttribute("aria-selected", String(number === index));
    tab.tabIndex = number === index ? 0 : -1;
  });
  document.getElementById("journey-panel").setAttribute("aria-labelledby", "step-tab-" + index);
  document.getElementById("journey-tag").textContent = step.tag;
  document.getElementById("journey-title").textContent = step.title;
  document.getElementById("journey-description").textContent = step.description;
  document.querySelectorAll(".demo-line").forEach((line, number) => {
    line.querySelector("span").textContent = step.labels[number];
    line.querySelector("strong").textContent = step.values[number];
  });
  document.querySelector(".demo-bottom").innerHTML = '<span class="spark" aria-hidden="true">✳</span>' + step.note;
  if (!reduceMotion.matches) document.querySelector(".profile-demo").animate([
    { opacity: .25, transform: "translateY(12px) rotate(-2deg)" },
    { opacity: 1, transform: "translateY(0) rotate(-2deg)" }
  ], { duration: 420, easing: "ease-out" });
}
tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => chooseStep(index));
  tab.addEventListener("keydown", event => {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % tabs.length;
    else if (event.key === "ArrowLeft") next = (index - 1 + tabs.length) % tabs.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = tabs.length - 1;
    else return;
    event.preventDefault();
    chooseStep(next);
    tabs[next].focus();
  });
});

