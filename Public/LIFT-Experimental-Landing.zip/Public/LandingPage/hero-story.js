"use strict";

// One cycle is 12.5 seconds. Each scene is a layer in hero-story.css.
(() => {
  const story = document.getElementById("hero-story");
  if (!story) return;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const labels = ["01 / YOUR LIFE", "02 / LIFT AI", "03 / YOUR PLAN", "04 / HUMAN SUPPORT", "05 / YOUR PROGRESS"];
  const durations = [2600, 2500, 2500, 2500, 2400];
  const aiMessages = [
    "Understanding your lifestyle",
    "Analyzing your goals",
    "Balancing your schedule",
    "Personalizing your plan"
  ];
  const stepLabel = document.getElementById("story-step-label");
  const status = document.getElementById("ai-status");
  const stageNames = [...story.querySelectorAll(".story-stage-names span")];
  let sceneTimer = 0;
  let statusTimer = 0;
  let currentScene = 0;

  function clearTimers() {
    clearTimeout(sceneTimer);
    clearInterval(statusTimer);
  }

  function showScene(scene) {
    currentScene = scene;
    story.dataset.scene = String(scene);
    stepLabel.textContent = labels[scene - 1];
    stageNames.forEach((name, index) => name.classList.toggle("is-active", index === scene - 1));
    clearInterval(statusTimer);
    if (scene === 2) {
      let messageIndex = 0;
      status.textContent = aiMessages[messageIndex];
      statusTimer = window.setInterval(() => {
        messageIndex = (messageIndex + 1) % aiMessages.length;
        status.textContent = aiMessages[messageIndex];
      }, 600);
    }
    sceneTimer = window.setTimeout(() => {
      if (scene === 5) startStory();
      else showScene(scene + 1);
    }, durations[scene - 1]);
  }

  function startStory() {
    clearTimers();
    story.classList.remove("is-playing");
    story.dataset.scene = "0";
    if (reduceMotion.matches) {
      story.dataset.scene = "5";
      stepLabel.textContent = labels[4];
      stageNames.forEach((name, index) => name.classList.toggle("is-active", index === 4));
      return;
    }
    // Restart CSS entry and progress animations at the start of each loop.
    void story.offsetWidth;
    story.classList.add("is-playing");
    showScene(1);
  }

  window.addEventListener("lift:intro-started", () => {
    clearTimers();
    story.classList.remove("is-playing");
    story.dataset.scene = "0";
  });
  window.addEventListener("lift:intro-finished", startStory);
  reduceMotion.addEventListener("change", () => {
    if (!document.body.classList.contains("intro-running")) startStory();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clearTimers();
    else if (!document.body.classList.contains("intro-running")) startStory();
  });

  story.addEventListener("pointermove", (event) => {
    if (reduceMotion.matches || event.pointerType !== "mouse") return;
    const bounds = story.getBoundingClientRect();
    const x = ((event.clientX - bounds.left) / bounds.width - .5) * 12;
    const y = ((event.clientY - bounds.top) / bounds.height - .5) * 10;
    story.style.setProperty("--story-x", `${x}px`);
    story.style.setProperty("--story-y", `${y}px`);
  });
  story.addEventListener("pointerleave", () => {
    story.style.setProperty("--story-x", "0px");
    story.style.setProperty("--story-y", "0px");
  });

  if (document.body.classList.contains("intro-running")) story.dataset.scene = "0";
  else startStory();
})();
