"use strict";

const contactForm = document.getElementById("contact-form");
const contactStatus = document.getElementById("form-status");

contactForm.addEventListener("submit", event => {
  event.preventDefault();
  if (!contactForm.reportValidity()) return;
  contactStatus.hidden = false;
  contactStatus.textContent = "Your message is ready. This static preview cannot send or save it yet.";
});

