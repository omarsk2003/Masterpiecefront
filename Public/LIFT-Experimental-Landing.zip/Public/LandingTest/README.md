# LIFT Experimental Hero

Open `index.html` directly or with the project's existing local server at `/Public/LandingTest/index.html`.

The visual prototype has an automatic, approximately eight-second **LIFT Experimental Cinematic Intro**: one real athlete prepares and runs, with subtle fuel and recovery images, a quiet adaptation cue, and a progress line. The footage stays the human anchor while the film pulls back and crossfades into the existing LIFT photo-sphere Hero.

## Isolated files

- `experimental-hero/lift-opening-intro.css` and `lift-opening-intro.js`: opening sequence only.
- Opening markup sits between the **LIFT Opening Intro** comments in `index.html`.
- `experimental-hero/lift-experimental-hero.css` and `lift-experimental-hero.js`: preserved final Hero composition and its independent image-sphere animation.
- `experimental-hero/assets/`: local video and photography; there are no remote media requests.
- `experimental-hero/CREDITS.md`: asset sources.

To remove the intro, remove its two dedicated CSS/JS includes and its markup block. The existing Hero then appears directly. The production landing page and application functionality are not part of this experiment.

## Performance and accessibility

The muted video loads only when the stage enters view and pauses offscreen/background. The Hero's existing sphere waits during the intro and starts at the reveal. Reduced-motion preferences show the still Hero immediately. Autoplay denial, media errors or a three-second loading/stall timeout reveal the existing Hero automatically. Story images are local, small, and lazily decoded. All photographic layers are decorative to assistive technology.

Run `node Public/LandingTest/experimental-hero/verify.cjs` for the project’s source/runtime simulation checks. These do not verify actual browser pixels or device frame rates.
