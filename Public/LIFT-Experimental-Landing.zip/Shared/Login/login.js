"use strict";

// Static preview accounts only. These are not real credentials or authentication.
// Never store real passwords in frontend code. Backend authentication comes later.
const previewAccounts = [
  { email: "client@lift.demo", password: "Lift2026!", page: "../../Client/Dashboard/dashboard.html" },
  { email: "coach@lift.demo", password: "Lift2026!", page: "../../Coach/Dashboard/dashboard.html" },
  { email: "nutritionist@lift.demo", password: "Lift2026!", page: "../../Nutrition/Dashboard/dashboard.html" },
  { email: "admin@lift.demo", password: "Lift2026!", page: "../../Admin/Dashboard/dashboard.html" }
];

const form = document.getElementById("login-form");
const email = document.getElementById("email");
const password = document.getElementById("password");
const passwordToggle = document.getElementById("toggle-password");
const message = document.getElementById("form-message");
const submitButton = document.getElementById("sign-in");
const status = document.getElementById("sign-in-status");
const recoveryDialog = document.getElementById("recovery-dialog");
let redirectTimer;

function setError(input, text) {
  document.getElementById(input.id + "-error").textContent = text;
  input.setAttribute("aria-invalid", String(Boolean(text)));
}

function clearMessage() {
  message.hidden = true;
  message.textContent = "";
}

[email, password].forEach(input => {
  input.addEventListener("input", () => {
    setError(input, "");
    clearMessage();
  });
});

passwordToggle.addEventListener("click", () => {
  const visible = password.type === "password";
  password.type = visible ? "text" : "password";
  passwordToggle.setAttribute("aria-label", visible ? "Hide password" : "Show password");
  passwordToggle.setAttribute("aria-pressed", String(visible));
});

form.addEventListener("submit", async event => {
  event.preventDefault();
  if (submitButton.disabled) return;
  clearMessage();
  const address = email.value.trim();
  email.value = address;
  const emailError = !address ? "Enter your email address." : email.validity.typeMismatch ? "Enter a valid email address." : "";
  const passwordError = !password.value ? "Enter your password." : "";
  setError(email, emailError);
  setError(password, passwordError);
  if (emailError || passwordError) {
    (emailError ? email : password).focus();
    return;
  }
  let account = previewAccounts.find(item => item.email === address.toLowerCase() && item.password === password.value);
  if (!account) {
    try {
      const applications = await window.LiftSpecialistApplications.all();
      const application = applications.find(item => item.email === address.toLowerCase());
      if (application && await window.LiftSpecialistApplications.verifyCredential(application, password.value)) {
        if (application.status !== "active") {
          message.textContent = ({ pending: "Your application is awaiting admin review.", rejected: "Your application was not approved.", blocked: "This account is blocked." })[application.status] || "This account is not active.";
          message.hidden = false;
          return;
        }
        account = { page: application.role === "coach" ? "../../Coach/Dashboard/dashboard.html" : "../../Nutrition/Dashboard/dashboard.html" };
      }
    } catch {
      message.textContent = "Local account storage is unavailable in this browser. Try opening LIFT on a local server.";
      message.hidden = false;
      return;
    }
  }
  if (!account) {
    message.textContent = "The email or password doesn't match. Please try again.";
    message.hidden = false;
    password.focus();
    return;
  }
  submitButton.disabled = true;
  submitButton.querySelector(".button-arrow").hidden = true;
  submitButton.querySelector(".spinner").hidden = false;
  submitButton.querySelector("span").textContent = "Opening your dashboard";
  status.textContent = "Welcome back. Taking you to your dashboard…";
  redirectTimer = window.setTimeout(() => window.location.assign(account.page), 650);
});

document.getElementById("forgot-password").addEventListener("click", () => recoveryDialog.showModal());
document.getElementById("close-recovery").addEventListener("click", () => recoveryDialog.close());
recoveryDialog.addEventListener("click", event => {
  const rect = recoveryDialog.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) recoveryDialog.close();
});
// Restore the form when navigating back from a preview dashboard.
window.addEventListener("pageshow", () => {
  clearTimeout(redirectTimer);
  submitButton.disabled = false;
  submitButton.querySelector(".button-arrow").hidden = false;
  submitButton.querySelector(".spinner").hidden = true;
  submitButton.querySelector("span").textContent = "Sign in";
  status.textContent = "";
});


