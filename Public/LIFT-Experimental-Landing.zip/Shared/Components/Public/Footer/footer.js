"use strict";
(() => {
  const root = new URL("../../../../", document.currentScript.src);
  const landing = new URL("Public/LandingPage/landing-page.html",root).href;
  class LiftFooter extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `<footer class="public-footer"><div class="footer-top"><div class="footer-brand-block"><a class="footer-brand" href="${landing}" aria-label="LIFT home"><img src="${new URL("Shared/Assets/Images/lift-logo.png",root).href}" alt="LIFT"></a><p>A healthier life.<br>A rhythm that's yours.</p></div><div class="footer-column"><h2>EXPLORE LIFT</h2><a href="${landing}#approach">The approach</a><a href="${landing}#how-it-works">How it works</a><a href="${landing}#plans">Memberships</a></div><div class="footer-column"><h2>BUILD WITH US</h2><a href="${new URL("Coach/Registration/registration.html",root).href}">Become a coach ↗</a><a href="${new URL("Nutrition/Registration/registration.html",root).href}">Become a nutritionist ↗</a><a href="${new URL("Public/ContactUs/contact-us.html",root).href}">Get in touch ↗</a></div><div class="footer-statement">A little progress.<br><em>Every single day.</em><span>✳</span></div></div><div class="footer-bottom"><span>© 2026 LIFT. All rights reserved.</span><span>LIFESTYLE & INTELLIGENT FITNESS TECHNOLOGY</span><a href="#home">BACK TO TOP ↑</a></div></footer>`;
    }
  }
  customElements.define("lift-footer",LiftFooter);
})();


